package db;

import java.util.Scanner;

public class Main {
	public static void main(String[]args) {
		Scanner sc=new Scanner (System.in);
		
		Product pro=new Product();
		Customer c=new Customer();
	/*	Billing.generateBill();*/
		
		  while (true) {
	            System.out.println("\n====== Grocery Billing System ======");
	            System.out.println("1. Manage Products");
	            System.out.println("2. Manage Customers");
	            System.out.println("3. Billing Module");
	            System.out.println("4. Exit");
	            System.out.print("Choose: ");
	            int choice = sc.nextInt();

	            switch (choice) {
	                case 1:
	                    Product.ManageProduct();
	                    break;
	                case 2:
	                	Customer.ManageCustomer();
	                	break;
	                case 3:
	                	Billing.generateBill();
	                	break;
	                case 4:
	                    System.out.println("Exiting...");
	                    System.exit(0);
	            }
	        }
		
	}
}
