package db;

import java.sql.*;

public class DbConnection {
	private static final String url="jdbc:mysql://localhost:3306/GROCERY";
	private static final String username="root";
	private static final String password="Smru@123";
	
	
	public static Connection getConnection() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			return DriverManager.getConnection(url,username,password);
		}catch(Exception e) {
			System.out.println("jdbc connection error"+e);
			return null;
		}
	}
	
}
