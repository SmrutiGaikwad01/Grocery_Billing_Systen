package db;

import java.sql.*;
import java.util.Scanner;

public class Product {
    static Scanner sc = new Scanner(System.in);

    public static void ManageProduct() {
        while (true) {
            System.out.println("\n----- Manage Product -----");
            System.out.println("1. Add product");
            System.out.println("2. View product");
            System.out.println("3. Update product");
            System.out.println("4. Delete product");
            System.out.println("5. Back to menu");
            System.out.print("Enter your choice: ");
            int ch = sc.nextInt();

            switch (ch) {
                case 1: addProduct(); break;
                case 2: viewProduct(); break;
                case 3: updateProduct(); break;
                case 4: deleteProduct(); break;
                case 5: return;
                default: System.out.println("Invalid Choice");
            }
        }
    }

    public static void addProduct() {
        try (Connection con = DbConnection.getConnection()) {
            System.out.print("Product Name: ");
            sc.nextLine(); // clear input buffer
            String name = sc.nextLine();

            System.out.print("Product Price: ");
            int price = sc.nextInt();

            System.out.print("Stock: ");
            int stock = sc.nextInt();

            String query = "INSERT INTO GROCERY(Product_Name, Product_Price, Product_Stock) VALUES (?, ?, ?)";
            PreparedStatement p = con.prepareStatement(query);
            p.setString(1, name);
            p.setInt(2, price);
            p.setInt(3, stock);

            int rows = p.executeUpdate();
            System.out.println(rows > 0 ? "Product Added!" : "Failed to Add");
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public static void viewProduct() {
        try (Connection con = DbConnection.getConnection()) {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM GROCERY");

            System.out.println("\nID | Name\t| Price | Stock");
            System.out.println("----------------------------------");
            while (rs.next()) {
                System.out.printf("%d | %s\t| %d | %d\n",
                        rs.getInt("Product_id"),
                        rs.getString("Product_Name"),
                        rs.getInt("Product_Price"),
                        rs.getInt("Product_Stock"));
            }
        } catch (Exception e) {
            System.out.println( e);
        }
    }

    public static void updateProduct() {
        try (Connection con = DbConnection.getConnection()) {
            System.out.print("Enter Product ID to Update: ");
            int id = sc.nextInt();

            System.out.print("New Name: ");
            sc.nextLine(); // clear buffer
            String name = sc.nextLine();

            System.out.print("New Price: ");
            int price = sc.nextInt();

            System.out.print("New Stock: ");
            int stock = sc.nextInt();

            String query = "UPDATE GROCERY SET Product_Name=?, Product_Price=?, Product_Stock=? WHERE Product_id=?";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1, name);
            pst.setInt(2, price);
            pst.setInt(3, stock);
            pst.setInt(4, id);

            int rows = pst.executeUpdate();
            System.out.println(rows > 0 ? "Product Updated!" : " Update Failed");
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public static void deleteProduct() {
        try (Connection con = DbConnection.getConnection()) {
            System.out.print("Enter Product ID to Delete: ");
            int id = sc.nextInt();

            String query = "DELETE FROM GROCERY WHERE Product_id=?";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setInt(1, id);

            int rows = pst.executeUpdate();
            System.out.println(rows > 0 ? "Product Deleted!" : "Delete Failed");
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
