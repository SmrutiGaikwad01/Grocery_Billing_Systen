package db;

import java.sql.*;
import java.util.Scanner;

public class Customer {
    static Scanner sc = new Scanner(System.in);

    public static void ManageCustomer() {
        while (true) {
            System.out.println("\n----- Manage Customer -----");
            System.out.println("1. Add Customer");
            System.out.println("2. View Customers");
            System.out.println("3. Update Customer");
            System.out.println("4. Delete Customer");
            System.out.println("5. Back to Menu");
            System.out.print("Enter your choice: ");
            int ch = sc.nextInt();

            switch (ch) {
                case 1: addCustomer(); break;
                case 2: viewCustomers(); break;
                case 3: updateCustomer(); break;
                case 4: deleteCustomer(); break;
                case 5: return;
                default: System.out.println(" Invalid choice");
            }
        }
    }

    public static void addCustomer() {
        try (Connection con = DbConnection.getConnection()) {
            System.out.print("Customer Name: ");
            sc.nextLine(); // Clear buffer
            String name = sc.nextLine();

            System.out.print("Contact Number: ");
            String contact = sc.nextLine();

            System.out.print("Address: ");
            String address = sc.nextLine();

            String query = "INSERT INTO CUSTOMER (Customer_Name, Customer_Contact, Customer_Address) VALUES (?, ?, ?)";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1, name);
            pst.setString(2, contact);
            pst.setString(3, address);

            int rows = pst.executeUpdate();
            System.out.println(rows > 0 ? " Customer Added!" : "❌ Failed to Add");
        } catch (Exception e) {
            System.out.println(" Error: " + e);
        }
    }

    public static void viewCustomers() {
        try (Connection con = DbConnection.getConnection()) {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM CUSTOMER");

            System.out.println("\nID | Name\t| Contact\t| Address");
            System.out.println("-------------------------------------------------------");

            while (rs.next()) {
                System.out.printf("%d | %s\t| %s\t| %s\n",
                        rs.getInt("Customer_id"),
                        rs.getString("Customer_Name"),
                        rs.getString("Customer_Contact"),
                        rs.getString("Customer_Address"));
            }
        } catch (Exception e) {
            System.out.println( e);
        }
    }

    public static void updateCustomer() {
        try (Connection con = DbConnection.getConnection()) {
            System.out.print("Enter Customer ID to update: ");
            int id = sc.nextInt();

            System.out.print("New Name: ");
            sc.nextLine(); // clear buffer
            String name = sc.nextLine();

            System.out.print("New Contact: ");
            String contact = sc.nextLine();

            System.out.print("New Address: ");
            String address = sc.nextLine();

            String query = "UPDATE CUSTOMER SET Customer_Name=?, Customer_Contact=?, Customer_Address=? WHERE Customer_id=?";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1, name);
            pst.setString(2, contact);
            pst.setString(3, address);
            pst.setInt(4, id);

            int rows = pst.executeUpdate();
            System.out.println(rows > 0 ? " Customer Updated!" : "Update Failed");
        } catch (Exception e) {
            System.out.println("❌ Error: " + e);
        }
    }

    public static void deleteCustomer() {
        try (Connection con = DbConnection.getConnection()) {
            System.out.print("Enter Customer ID to delete: ");
            int id = sc.nextInt();

            String query = "DELETE FROM CUSTOMER WHERE Customer_id=?";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setInt(1, id);

            int rows = pst.executeUpdate();
            System.out.println(rows > 0 ? " Customer Deleted!" : "❌ Delete Failed");
        } catch (Exception e) {
            System.out.println( e);
        }
    }
}
