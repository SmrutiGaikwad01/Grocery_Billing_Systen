package db;

import java.sql.*;
import java.util.*;

public class Billing {
    static Scanner sc = new Scanner(System.in);

    public static void generateBill() {
        try (Connection con = DbConnection.getConnection()) {
            System.out.print("Enter Customer Name: ");
            sc.nextLine(); 
            String customerName = sc.nextLine();

            List<String> products = new ArrayList<>();
            List<Integer> qtys = new ArrayList<>();
            List<Integer> prices = new ArrayList<>();
            List<Integer> subtotals = new ArrayList<>();

            int total = 0;

            while (true) {
                System.out.print("Enter Product Name (or 'done' to finish): ");
                String pname = sc.nextLine();
                if (pname.equalsIgnoreCase("done")) break;

                System.out.print("Enter Quantity: ");
                int qty = sc.nextInt();
                sc.nextLine();

                
                String q = "SELECT Product_Price FROM GROCERY WHERE Product_Name=?";
                PreparedStatement pst = con.prepareStatement(q);
                pst.setString(1, pname);
                ResultSet rs = pst.executeQuery();

                if (rs.next()) {
                    int price = rs.getInt("Product_Price");
                    int subtotal = price * qty;
                    total += subtotal;

                    products.add(pname);
                    qtys.add(qty);
                    prices.add(price);
                    subtotals.add(subtotal);

                    System.out.println("Added: " + pname + " x" + qty + " = ₹" + subtotal);
                } else {
                    System.out.println(" Product not found!");
                }
            }

            
            String insertBill = "INSERT INTO BILL (Customer_Name, Total_Amount) VALUES (?, ?)";
            PreparedStatement billStmt = con.prepareStatement(insertBill, Statement.RETURN_GENERATED_KEYS);
            billStmt.setString(1, customerName);
            billStmt.setInt(2, total);
            billStmt.executeUpdate();

            ResultSet rsBill = billStmt.getGeneratedKeys();
            int billId = 0;
            if (rsBill.next()) {
                billId = rsBill.getInt(1);
            }

            // Insert all items into BILL_DETAILS
            String insertDetail = "INSERT INTO BILL_DETAILS (Bill_id, Product_Name, Quantity, Price, Subtotal) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement detailStmt = con.prepareStatement(insertDetail);

            for (int i = 0; i < products.size(); i++) {
                detailStmt.setInt(1, billId);
                detailStmt.setString(2, products.get(i));
                detailStmt.setInt(3, qtys.get(i));
                detailStmt.setInt(4, prices.get(i));
                detailStmt.setInt(5, subtotals.get(i));
                detailStmt.executeUpdate();
            }

            System.out.println("\n Bill Generated Successfully!");
            System.out.println("Total Amount: ₹" + total);
        } catch (Exception e) {
            System.out.println("Error in billing: " + e);
        }
    }

    public static void viewAllBills() {
        try (Connection con = DbConnection.getConnection()) {
            String query = "SELECT * FROM BILL ORDER BY Date_Time DESC";
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(query);

            System.out.println("\n----- All Bills -----");
            while (rs.next()) {
                System.out.printf("Bill ID: %d | Customer: %s | Total: ₹%d | Date: %s\n",
                        rs.getInt("Bill_id"),
                        rs.getString("Customer_Name"),
                        rs.getInt("Total_Amount"),
                        rs.getTimestamp("Date_Time"));
            }
        } catch (Exception e) {
            System.out.println(" Error viewing bills: " + e);
        }
    }

    public static void viewBillDetails() {
        try (Connection con = DbConnection.getConnection()) {
            System.out.print("Enter Bill ID: ");
            int billId = sc.nextInt();

            String query = "SELECT * FROM BILL_DETAILS WHERE Bill_id=?";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setInt(1, billId);
            ResultSet rs = pst.executeQuery();

            System.out.println("\nProduct | Qty | Price | Subtotal");
            System.out.println("---------------------------------");
            while (rs.next()) {
                System.out.printf("%s | %d | ₹%d | ₹%d\n",
                        rs.getString("Product_Name"),
                        rs.getInt("Quantity"),
                        rs.getInt("Price"),
                        rs.getInt("Subtotal"));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
